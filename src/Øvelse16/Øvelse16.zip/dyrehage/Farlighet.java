package Øvelse16.dyrehage;

public enum Farlighet {
    Harmløs,LittFarlig, Skadelig, Dødelig
}